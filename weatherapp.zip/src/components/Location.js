import React from 'react';

const Location = (props) => { 
    console.log("props" , props);
    debugger
    return ( <div><h1>Bologna</h1></div> );
}

export default Location;