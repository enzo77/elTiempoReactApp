import React from 'react';
 
const WeatherTemperature = () => (
    <div><span>12 C</span></div>
)

export default WeatherTemperature;