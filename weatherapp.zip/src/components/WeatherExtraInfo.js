import React from 'react';

const WeatherExtraInfo = () => (
    <div>Extra Info</div>
)

export default WeatherExtraInfo;

